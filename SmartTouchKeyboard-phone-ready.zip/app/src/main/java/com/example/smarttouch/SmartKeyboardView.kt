package com.example.smarttouch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

class SmartKeyboardView(context: Context, val onKey: (String) -> Unit) : View(context) {
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF17191F.toInt() }
    private val keyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF30343D.toInt() }
    private val specialPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF454B58.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF4F5F7.toInt(); textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif", Typeface.NORMAL)
    }
    private data class Key(val label: String, val value: String, val rect: RectF, val special: Boolean = false)
    private val keys = mutableListOf<Key>()
    private var english = false
    private var before = ""
    private var pendingCorrection: Pair<Float, Float>? = null
    private val prefs = context.getSharedPreferences("smarttouch_local", Context.MODE_PRIVATE)
    private var density = resources.displayMetrics.density

    fun toggleLanguage() { english = !english; invalidate() }
    fun refreshContext(text: String) { before = text.takeLast(3); invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = (250 * density).toInt()
        setMeasuredDimension(w, h)
    }

    private fun buildKeys() {
        keys.clear()
        val w = width.toFloat()
        val pad = 5f * density
        val gap = 5f * density
        val top = 8f * density
        val rowH = 49f * density
        val rows = if (english) listOf("qwertyuiop", "asdfghjkl", "zxcvbnm") else listOf("йцукенгшщзх", "фывапролджэ", "ячсмитьбю")
        rows.forEachIndexed { ri, row ->
            val rowWidth = w - 2 * pad - (row.length - 1) * gap
            val kw = rowWidth / row.length
            val offset = if (ri == 1) 0.045f * w else if (ri == 2) 0.14f * w else 0f
            row.forEachIndexed { ci, c ->
                val left = pad + offset + ci * (kw + gap)
                val rect = RectF(left, top + ri * (rowH + gap), left + kw, top + ri * (rowH + gap) + rowH)
                keys.add(Key(c.toString(), c.toString(), rect))
            }
        }
        val y = top + 3 * (rowH + gap)
        val bottomH = 47f * density
        fun special(label: String, value: String, left: Float, right: Float) {
            keys.add(Key(label, value, RectF(left, y, right, y + bottomH), true))
        }
        special("?123", "<LANG>", pad, w * .19f)
        special(",", ",", w * .205f, w * .30f)
        special("Рус/En", "<LANG>", w * .315f, w * .49f)
        special("пробел", "<SPACE>", w * .505f, w * .79f)
        special(".", ".", w * .805f, w * .89f)
        special("⌫", "<DEL>", w * .905f, w - pad)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        buildKeys()
        keys.forEach { key ->
            canvas.drawRoundRect(key.rect, 7f * density, 7f * density, if (key.special) specialPaint else keyPaint)
            textPaint.textSize = if (key.special) 12f * density else 21f * density
            val baseline = key.rect.centerY() - (textPaint.ascent() + textPaint.descent()) / 2
            canvas.drawText(key.label, key.rect.centerX(), baseline, textPaint)
        }
    }

    private fun transitionScore(char: Char): Float {
        val prev = before.lastOrNull()?.lowercaseChar() ?: return 1f
        val c = char.lowercaseChar()
        val common = when (prev) {
            'п' -> "роае"
            'р' -> "аеои"
            'с' -> "тпко"
            'т' -> "оеаи"
            'к' -> "аои"
            'в' -> "аео"
            'q' -> "uw"
            't' -> "hrea"
            's' -> "thae"
            else -> ""
        }
        return if (c in common) 1.18f else 0.92f
    }

    private fun choose(x: Float, y: Float): Key? {
        val letters = keys.filter { !it.special }
        if (letters.isEmpty()) return null
        var best: Key? = null
        var bestScore = Float.NEGATIVE_INFINITY
        for (key in letters) {
            val cx = key.rect.centerX()
            val cy = key.rect.centerY()
            val dx = (x - cx) / max(1f, key.rect.width() * .55f)
            val dy = (y - cy) / max(1f, key.rect.height() * .65f)
            val distanceScore = exp(-(dx * dx + dy * dy) * 1.35f)
            val biasX = prefs.getFloat("bias_${key.value}_x", 0f)
            val biasY = prefs.getFloat("bias_${key.value}_y", 0f)
            val bx = (x - (cx + biasX)) / max(1f, key.rect.width() * .55f)
            val by = (y - (cy + biasY)) / max(1f, key.rect.height() * .65f)
            val adjustedDistance = exp(-(bx * bx + by * by) * 1.35f)
            val score = adjustedDistance * transitionScore(key.value[0])
            if (score > bestScore) { bestScore = score; best = key }
        }
        return best
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_UP -> {
                val x = event.x; val y = event.y
                val special = keys.firstOrNull { it.special && it.rect.contains(x, y) }
                if (special != null) {
                    onKey(special.value)
                    if (special.value == "<DEL>") pendingCorrection = x to y
                } else {
                    val chosen = choose(x, y)
                    if (chosen != null) {
                        // If the user deleted a character and immediately types its replacement,
                        // slowly shift the corrected key's effective hit area toward that touch.
                        pendingCorrection?.let { (oldX, oldY) ->
                            val dx = (oldX - x) * .08f
                            val dy = (oldY - y) * .08f
                            val k = chosen.value
                            prefs.edit()
                                .putFloat("bias_${k}_x", prefs.getFloat("bias_${k}_x", 0f) + dx)
                                .putFloat("bias_${k}_y", prefs.getFloat("bias_${k}_y", 0f) + dy)
                                .apply()
                            pendingCorrection = null
                        }
                        before = (before + chosen.value).takeLast(3)
                        onKey(chosen.value)
                    }
                }
                performClick()
            }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}

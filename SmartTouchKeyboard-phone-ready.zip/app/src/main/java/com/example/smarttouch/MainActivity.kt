package com.example.smarttouch

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(0xFF15171C.toInt())
        }
        val title = TextView(this).apply {
            text = "SmartTouch Keyboard"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val info = TextView(this).apply {
            text = "Клавиатура выбирает букву по точке касания и контексту соседних букв. Ввод обрабатывается на устройстве; текст не отправляется в интернет."
            textSize = 16f
            setTextColor(0xFFD5D8E0.toInt())
            setPadding(0, 24, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1. Включить клавиатуру"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        }
        val choose = Button(this).apply {
            text = "2. Выбрать SmartTouch"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        root.addView(title); root.addView(info); root.addView(enable); root.addView(choose)
        setContentView(root)
    }
}

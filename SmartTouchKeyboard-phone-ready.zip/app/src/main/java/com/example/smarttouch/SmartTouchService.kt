package com.example.smarttouch

import android.inputmethodservice.InputMethodService
import android.view.View

class SmartTouchService : InputMethodService() {
    private var keyboard: SmartKeyboardView? = null

    override fun onCreateInputView(): View {
        keyboard = SmartKeyboardView(this) { value ->
            val ic = currentInputConnection ?: return@SmartKeyboardView
            when (value) {
                "<DEL>" -> ic.deleteSurroundingText(1, 0)
                "<ENTER>" -> ic.commitText("\n", 1)
                "<SPACE>" -> ic.commitText(" ", 1)
                "<LANG>" -> keyboard?.toggleLanguage()
                else -> ic.commitText(value, 1)
            }
        }
        return keyboard!!
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        keyboard?.refreshContext(currentInputConnection?.getTextBeforeCursor(3, 0)?.toString().orEmpty())
    }
}
